<script>
export default {
  name: "Tariffs"
}
</script>

<template>
  <section>
    <div class="container">
      tariffs
    </div>
  </section>
</template>

<style scoped>

</style>