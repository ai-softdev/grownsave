<script>
export default {
  name: "Footer"
}
</script>

<template>
  <footer class="footer flex items-center justify-center w-full">
  </footer>
</template>

<style scoped>
.footer {
  min-height: 78px;
  padding: 16px 0;
  background: url("/img/bg.png");
}
</style>