<script>
export default {
  name: "MainSubtitle"
}
</script>

<template>
  <p class="mt-[32px] text-[16px] text-white opacity-80 max_sm:text-[14px] break-words">
    <slot/>
  </p>
</template>

<style scoped>

</style>