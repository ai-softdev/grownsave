<script>
export default {
  name: "AIButton"
}
</script>

<template>
  <button class="bg-gradient-to-b from-violet to-lightViolet rounded-full p-3 text-white font-bold">
    <slot/>
  </button>
</template>

<style scoped>

</style>