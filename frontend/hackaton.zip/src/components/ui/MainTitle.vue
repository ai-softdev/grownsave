<script>
export default {
  name: "MainTitle"
}
</script>

<template>
  <h1 class="font-bold text-3xl max_big:text-2xl max_lit:text-xl text-center">
    <slot/>
  </h1>
</template>

<style scoped>

</style>