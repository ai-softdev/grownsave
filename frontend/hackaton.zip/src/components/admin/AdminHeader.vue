<script>
import Header from "../main/Header.vue";

export default {
  name: "AdminHeader",
  components: {Header}
}
</script>

<template>
  <header class="header flex h-[70px] items-center justify-center w-full">
    <img src="/img/logo.svg" class="logo mx-auto w-[170px] h-[60px] object-contain font-bold"/>
  </header>
</template>

<style scoped>

</style>