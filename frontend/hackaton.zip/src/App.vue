<script>
</script>

<template>
  <transition name="blur-fade">
    <router-view/>
  </transition>
</template>

<style scoped>
</style>
